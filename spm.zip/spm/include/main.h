#ifndef __MAIN_H__
#define __MAIN_H__

#include <struct.h>

extern stock*  searchStockName (stock* headPointer, int stockName);
extern int  loadFromFile(const char* fileName, stock **);
extern void display_stock(stock* st);
extern void printLinkedList(stock *);
extern int  freeLinkedList(stock **);
extern void append(stock **headPointer, stock* data);
//extern void selectChoice(FILE** fptr);
extern void selectChoice(stock** st);
//extern void  menu(stock** st);
extern void  menu(stock** st);
extern void doFindReport();
extern void doAddTransaction(stock** st);

#endif


#include <stdio.h>
#include <stdlib.h>
#include <main.h>
#include <unistd.h>
#include <string.h>

/*
int doSaveFiles(stock** st)
{
	stock* iter = head;
	FILE *fp = fopen(fileName, "w");
	char seperator = ",";

	if ( fp != NULL)
	{
		while ( iter != NULL)
		{
		fprintf(fp, "%s%c%s%c%d%c%d%c%s%c%d%c%d\n", iter->stockName, seperator, iter->buyDate, seperator, iter->buyQty, seperator, iter->buyPrice, seperator, iter->sellDate, seperator, iter->sellQty, seperator, iter->sellPrice);
	       
		}
		close(fp);
	}
	else
		return EXIT_FAILURE;

	return EXIT_SUCCESS;
}
*/

void doFindReport(stock** st)
{
    int totalBuyPrice = 0;
    int totalSellPrice = 0;
    int buyQty = 0;
    int buyPrice = 0;
    int sellQty = 0;
    int sellPrice = 0;
    
    totalBuyPrice =  totalBuyPrice+(buyQty * buyPrice);
    totalSellPrice = totalSellPrice+(sellQty * sellPrice);

    if(totalSellPrice > totalBuyPrice)
    {
      	 int profit = totalSellPrice - totalBuyPrice;
   	 printf("%d\n",&profit);
   }
   
    else
    {  
    	
    	int loss = totalBuyPrice - totalSellPrice;
    	
	 printf("%d\n",&loss);
     }
        return ;
}

void doAddTransaction(stock** st)
{
	int buyQty = 0;
	int sellQty = 0;
	char buyDate[BUY_DATE_LEN] ;
	char sellDate[SELL_DATE_LEN] ;
	int buyPrice = 0;
	int sellPrice = 0;
	char stockName[STOCK_NAME_LEN];

	printf("Enter stock name");
	if(scanf("%s", stockName) != 1)
	{
	        fflush(stdin);
                printf("Please enter a valid name\n");
                return ;
	}

	 printf("Enter sell date of stock\n");
        if (scanf("%s", sellDate) != 1)
        {
                fflush(stdin);
                printf("Please enter a valid date\n");
                return ;
        }

	printf("Enter buy date of stock\n");
	if (scanf("%s", buyDate) != 1)
	{
		fflush(stdin);
		printf("Please enter a valid date\n");
		return ;
	}

	printf("Enter sell quantity of stock\n");
	if ( scanf("%d", &sellQty) != 0 )
	{
		fflush(stdin);
		printf("Please enter a valid quantity\n");
		return ;
	}

	printf("Enter sell price of stock\n");
        if ( scanf("%d", &sellPrice) != 0)
        {
                fflush(stdin);
                printf("Please enter a valid number\n");
                return ;
        }
        printf("Enter buy quantity of stock");
	if ( scanf("%d",&buyQty) != 0 )
	{
		fflush(stdin);
		printf("Please enter a valid quantity\n");
		return ;
	}

	printf("Enter buy price of stock\n");
	if ( scanf("%d", &buyPrice) != 0)
	{
		fflush(stdin);
		printf("Please enter a valid number\n");
		return ;
	}
	
    stock *newStock = (stock*)malloc(sizeof(stock));
    strcpy(newStock -> stockName, stockName);
    strcpy(newStock -> buyDate, buyDate);
    strcpy(newStock -> sellDate, sellDate);
    newStock -> buyQty = buyQty ;
    newStock -> sellQty = sellQty ;
    newStock -> buyPrice = buyPrice ;
    newStock -> sellPrice = sellPrice ;


}

void  menu(stock** st)
{
	int ch ;
	int returnValue = 0;
	
	do 
	{
	        system("clear");
	    printf("Welcome to Stock Portfolio Management Program\n");	
		printf("1. Add Transaction\n");
		printf("2. Display Report (Profit/Loss)\n");
		//printf("3. Save Files (Masters)\n");
		printf("3. Exit \n");

		returnValue = scanf ("%d", &ch);
		if ( returnValue == 0 || returnValue ==  EOF)
		{
			fflush(stdin);
			printf("Invalid input. Please enter valid input\n");
			continue ; // break;
		}
		
		loadFromFile("../data/transaction.csv", &st[0]);
		switch(ch)
		{
			case 1:
				doAddTransaction(st);
				break;
	
			case 2:
	
				doFindReport(st);
				break;
			//case 3:
			//	doSaveFiles(st);
			//	break;
		
			case 3:
				printf("Exiting\n");
				break;
			default:
			    printf("Invalid operation\n");
				break;
		}

	} while ( ch != 3);

}


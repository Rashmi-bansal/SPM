#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <struct.h>
#include <main.h>

/*********************************************************************
 *  freeLinkedList: Function takes address of the head node pointer
 *                  Itertates through the linked list and free 
 *                  allocated memory to each node.
 *  return value  : Returns the number of records freed.
 *********************************************************************/

/*********************************************************************
 *  prepend: Function takes address of the head node pointer
 *          and new empoyee structure address and adds the 
 *          node to the start of the linked list
 *********************************************************************/
/*
void prepend (stock **headPointer, stock* data)
{
    stock* temp = *headPointer ;
    *headPointer = data ;
    data -> next = temp;
//(*headPointer) -> next = temp;
}
*/

/*********************************************************************
 *  insertAfter: Function takes address of the head node pointer
 *               and new empoyee structure address and employee Id
 *               and adds the node after the node of empId in 
 *               the linked list
 *********************************************************************/
/*
int  insertAfter(int stockName, stock** headP, stock* newStock)
{
    int insert = 0;

    if ( newStock == NULL)
        return OPERATION_FAIL ;

    if (*headP == NULL )
        append(headP, newStock);

    stock* iter = *headP;

    while ( iter != NULL)   // Iterate through the list
    {
        if ( iter -> stockName == stockName )
        {
            // Insert after the current iter
            stock *temp = iter -> next;
            iter -> next = newStock ;
            newStock -> next = temp ;
            insert =  1;
            break;
        }
        iter = iter -> next;
    }
    if (insert == 1)
        return OPERATION_SUCCESS;
    else
        return OPERATION_FAIL ;

}
*/

/*************************************************************
 * serchEmpId : searcheds the linked list by empId 
 * return value : Returns the found structure pointer or NULL
 *
 ************************************************************/
/*
stock* searchStockName (stock* headPointer, int stockName)
{
	if (headPointer == NULL || stockName <= 0) 
		return NULL ;

	stock *iter = headPointer ;
	while ( iter != NULL )
	{
		if ( iter-> stockName == stockName )
		{
			return iter;
		}
		iter = iter -> next ;
	}
	return NULL ;
}
*/

/*************************************************************
 * searchEmpFirstName : searcheds the linked list by emp first name 
 * return value : Returns the found structure pointer or NULL
 *
 ************************************************************/
 
/*
stock* searchStockName (stock* headPointer, const char* stockName)
{
	
	if (headPointer == NULL || stockName == 0 || strlen(stockName) == 0)
        return NULL ;

	stock *returnList = NULL ;

	stock *iter = headPointer ;
	while ( iter != NULL )
	{
		if ( strcmp (iter-> stockName , stockName) == 0)
		{
			stock* temp = (stock*)malloc(sizeof(stock));
			*temp = *iter ;
//  or memcpy ( temp, iter, sizeof(employee);  OR
//       temp -> empId = iter -> empId ;
//       strcpy ( temp -> firstName , iter->firstName);
//         ....
//       temp -> salary = iter -> salary;
//       temp -> next = NULL ;

			append(&returnList, temp);
			//return iter;
		}
		iter = iter -> next ;
	}
	return returnList ;
}
*/




#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <struct.h>
#include <main.h>

/*
void freeHashTable(stock** st)
{
	for (int i=0; i < MAXSTOCK; i++)
	{
		if (st[i] != NULL)
			freeLinkedList(&st[i]);
	}
}
*/

//employee* searchEmpNameInHT (employee* headPointer, const char* empFirstName, const char* empLastName)

/*********************************************************************
 *  append: Function takes address of the head node pointer
 *          and new empoyee structure address and adds the 
 *          node to the end of the linked list
 *********************************************************************/
void append(stock **headPointer, stock* data)
{
    stock* iter = *headPointer ;

    if ( *headPointer == NULL ) //No  element in the linkedlist 
        *headPointer = data ;
    else
    {
        while ( iter -> next != NULL)
            iter = iter -> next;
        iter -> next = data ;
    }
    data -> next = NULL ;
}


int freeLinkedList(stock** st)
{
    stock* iter   = *st;
	int recordsFreed = 0;
    // Following code block frees the dynamically memory allocated 
    while ( iter != NULL )
    {
        stock* temp = iter ;
        iter = iter -> next ;
        if ( temp != NULL)
		{
            free (temp);
			recordsFreed++;
		}
    }
	return recordsFreed;

}




stock* searchStockNameInHT (stock* headPointer, int stock_Name)
{
    stock* iter = headPointer;

    while ( iter != NULL )
    {
		//if((strcmp(iter->firstName, empFirstName) == 0) && (strcmp(iter->lastName, empLastName) == 0))
		if(iter->stockName ==  stock_Name)
		{
			printf("Company found!!\n");
			break;
		}
        iter = iter -> next ;
    }
	return iter;

}

/*
stock* getStockFromHashTable(stock** st, int stockName)
//employee* getEmployeeFromHashTable(employee** emp, char* firstName, char* lastName)
{
	int index = HashFunction(stockName);
	printf("Hash Function returned %d\n", index);
	stock* e1 =  searchStockNameInHT(st[index], stockName);
	return e1 ;
}


int HashFunction(int key)
{
	int index = 0;
	index = key % (MAXSTOCK);
	return index;

}

void addStockToHashTable(stock** stockTable, stock* st)
{
	//int index = HashFunction(emp->firstName);
	int index = HashFunction(st->stockName);
	append(&stockTable[index], st); 
	
}
*/

void display_stock(stock* st)
{
    printf("| %s | %s | %d | %d | %s | %d | %d\n",
        st->stockName,
        st->buyDate,
        st->buyQty,
        st->buyPrice,
        st->sellDate,
        st->sellQty,
        st->sellPrice);
}
/*

void printHashTable(stock** st)
{
	for(int i =0; i < MAXSTOCK; i++)
	{
		printLinkedList(st[i]);
	}
}
*/

/*
void visualHashTable(stock** st)
{
	for(int i =0; i < MAXSTOCK; i++)
	{
		printf("%s[%d]:" , "bucket",  i); 
		printLinkedListName(&st[i]);
	}
}
*/


void printLinkedList(stock *st)
{
    stock* iter = st;
    while ( iter != NULL )
    {
        display_stock(iter);
        iter = iter -> next ;
    }

}

int loadFromFile(const char *fileName, stock **headPointer)
{
	char lineBuffer[STOCK_LINE_BUFFER];
	const char* seperator = "|" ;
	char* token = NULL ;
	stock *iter = NULL;

	FILE* transactionFile = fopen (fileName, "r");
	if (transactionFile == NULL )
    {
		printf("Issue opening the file %s\n", fileName);
		return EXIT_FAILURE ;
	}	

	while ( fgets ( lineBuffer, STOCK_LINE_BUFFER, transactionFile) != 0)
	{
		iter = (stock*) malloc (sizeof(stock));
		if ( iter == NULL )
		{
			printf("Could not allocate memory !\n");
			break;
		}

		token = strtok (lineBuffer, seperator);
		
		if ( token != NULL)
		{
			strcpy(iter -> stockName, token);
		}

		token = strtok (NULL, seperator);
		if ( token != NULL)
		{
			strcpy(iter -> buyDate, token);
			
		}

		token = strtok (NULL, seperator);
		if ( token != NULL)
		{
			iter -> buyQty = atoi(token);
		}

		token = strtok (NULL, seperator);
		if ( token != NULL)
		{
			iter -> buyPrice = atoi(token);
		}
		token = strtok (NULL, seperator);

		if ( token != NULL)
		{
			strcpy(iter -> sellDate, token);
		}
		token = strtok (NULL, seperator);

		if ( token != NULL)
		{
			iter -> sellQty = atoi(token);
		}


		token = strtok (lineBuffer, seperator);
		if ( token != NULL)
		{
			iter -> sellPrice = atoi(token);
		}

		iter -> next = NULL ;

		append( headPointer, iter );
		
	}

	fclose(transactionFile);

	return 0;
}




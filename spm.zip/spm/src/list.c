#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <main.h>
#include <struct.h>


/*
void selectChoice (FILE** fptr) 
{
while(1)
{
system("clear");
fflush(stdin);
int choice;

printf("\nList of Stocks\n\n1. AJANTA PHARMA\n2. BAJAJ ELECTRICALS\n3. CIPLA\n4. GODREJ PROP.\n5. INFOSYS\n6. HAVELLES\n7. HDFC BANK\n8. TESLA \n9. ICICI\n10.RAYMOND \n11.Exit\nEnter your choice:");
scanf("%d", &choice);

//*fptr= fopen(fileName,"r");
//*fptr = fopen ("../data/transaction.csv", "r");

switch (choice)
{
case 1:
printf("\nAJANTA PHARMA\n\n");
*fptr= fopen("../data/transaction.csv","r");
break;

case 2:
printf("\nBAJAJ ELECTRICALS\n\n");
//*fptr= fopen("../data/transaction.csv","r");
break;

case 3:
printf("\nCIPLA\n\n");
//*fptr= fopen("../data/transaction.csv", "r");
break;

case 4:
printf("\nGODREJ PROP.\n\n");
//*fptr= fopen("../data/transaction.csv", "r");
break;

case 5:
printf("\nINFOSYS\n\n");
//*fptr= fopen("../data/transaction.csv","r");
break;

case 6:
printf("\nHAVELLES\n\n");
//*fptr= fopen("../data/transaction.csv","r");
break;

case 7:
printf("\nHDFC BANK\n\n");
//*fptr= fopen("../data/transaction.csv","r");
break;

case 8:
printf("\nTESLA \n\n");
//*fptr= fopen("../data/transaction.csv","r");
break;

case 9:
printf("\nICICI\n\n");
//*fptr= fopen("../data/transaction.csv","r");
break;

case 10:
printf("\nRAYMOND\n\n");
//*fptr= fopen("../data/transaction.csv","r");
break;

case 11:
exit(0);
default:
printf("Invalid Selection");
break;
}
}
}

*/

void  selectChoice(stock** st)
{
	int choice;
	int returnValue = 0;
	
	do 
	{

	    printf("\nList of Stocks\n\n1. AJANTA PHARMA\n2. BAJAJ ELECTRICALS\n3. CIPLA\n4. GODREJ PROP.\n5. INFOSYS\n6. HAVELLES\n7. HDFC BANK\n8. TESLA \n9. ICICI\n10. RAYMOND \n11. Exit\nEnter your choice:");

		returnValue = scanf ("%d", &choice);
		if ( returnValue == 0 || returnValue ==  EOF)
		{
			fflush(stdin);
			printf("Invalid input. Please enter valid input\n");
			continue ; // break;
		}
		
		switch (choice)
		{
			case 1:
			printf("\nAJANTA PHARMA\n\n");
			FILE *fptr= fopen("../data/transaction.csv","r");
			menu(st);
			break;

			case 2:
			printf("\nBAJAJ ELECTRICALS\n\n");
			//*fptr= fopen("../data/transaction.csv","r");
			break;

			case 3:
			printf("\nCIPLA\n\n");
			//*fptr= fopen("../data/transaction.csv", "r");
			break;

			case 4:
			printf("\nGODREJ PROP.\n\n");
			//*fptr= fopen("../data/transaction.csv", "r");
			break;

			case 5:
			printf("\nINFOSYS\n\n");
			//*fptr= fopen("../data/transaction.csv","r");
			break;

			case 6:
			printf("\nHAVELLES\n\n");
			//*fptr= fopen("../data/transaction.csv","r");
			break;

			case 7:
			printf("\nHDFC BANK\n\n");
			//*fptr= fopen("../data/transaction.csv","r");
			break;

			case 8:
			printf("\nTESLA \n\n");
			//*fptr= fopen("../data/transaction.csv","r");
			break;

			case 9:
			printf("\nICICI\n\n");
			//*fptr= fopen("../data/transaction.csv","r");
			break;

			case 10:
			printf("\nRAYMOND\n\n");
			//*fptr= fopen("../data/transaction.csv","r");
			break;

			case 11:
			exit(0);
			default:
			printf("Invalid Selection");
			break;
			}
			} while ( choice != 11);
		

	}


